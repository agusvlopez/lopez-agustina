<template>
    <label class="block mb-1 font-semibold"><slot></slot></label>
</template>