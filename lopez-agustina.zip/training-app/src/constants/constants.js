export const BUTTON_SIZE_SMALL = 'small';
export const BUTTON_SIZE_NORMAL = 'normal';
export const BUTTON_SIZES = [BUTTON_SIZE_SMALL, BUTTON_SIZE_NORMAL];