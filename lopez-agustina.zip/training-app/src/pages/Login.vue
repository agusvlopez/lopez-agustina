<script setup>
import LoginForm from '../components/LoginForm.vue';
</script>

<template> 
<div class="min-h-screen flex items-center justify-center bg-gray-100">
    <div class="bg-white p-8 rounded-lg shadow-md w-96">
        <h1 class="font-bold mb-6">Iniciar sesión</h1>
        <LoginForm />
    </div>
</div>
</template>