<script setup>
import RegisterForm from '../components/RegisterForm.vue';

</script>

<template>
<div class="min-h-screen flex items-center justify-center bg-gray-100">
    <div class="bg-white p-8 rounded-lg shadow-md w-96">
    <h1 class="mb-6 font-bold">Crear cuenta</h1>
      <RegisterForm />
    </div>
</div>
</template>


