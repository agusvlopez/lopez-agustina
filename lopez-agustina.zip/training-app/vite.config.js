// Importamos el plugin de Vue.
import vue from '@vitejs/plugin-vue';

// Exportamos la configuración de Vite.
export default {
    // Agregamos el plugin de Vue.
    plugins: [vue()],
}
